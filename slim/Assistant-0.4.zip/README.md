## Squeezebox Remote control Home Assistant

This is a Plugin for Squeezebox server where you can control entities in Home Assistane.

This is tested on:
 - Squeezebox DUET Controller
 - Squeezebox Radio

Known limitations:
 - Menues sometimes get mixed
 - Menues are not updated without going back and forward

Add the repository URL https://hans99.github.io/slim/repo.xml

License information is found in the LICENSE file.