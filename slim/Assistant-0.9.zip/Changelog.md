#### Version 0.8
##### Added
- Add entity to handle group with common domain

#### Version 0.7
##### Fixed
- Settings info example proper url

#### Version 0.6
##### Added
- Support for switch
- Support for cover open/close

#### Version 0.5
##### Added
- Group status pics
##### Changed
- From toggle light to on/off
- New pics
##### Fixed
- Menu ordering